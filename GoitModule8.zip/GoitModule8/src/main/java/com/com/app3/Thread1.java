package com.com.app3;

/**
 * Created by Администратор on 17.07.2016.
 */
public class Thread1 extends Thread{
    private Person person;

    public Thread1(Person person) {
        this.person = person;
    }

    public void run(){
        synchronized (person) {
            System.out.println("Thread1." + person);
            person.setAge(1);
            person.setName("Name1");
            System.out.println("Thread1.After set values." + person);
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Thread1.Completed." + person);
        }
    }

}
