package com.com.app3;

/**
 * Created by Администратор on 17.07.2016.
 */
public class Main3 {

    public static void main(String[] args){
        Person p = new Person();
        p.setName("DefaultName");
        p.setAge(-1);
        Thread1 thread1 = new Thread1(p);
        Thread2 thread2 = new Thread2(p);
        thread1.start();
        thread2.start();
    }
}
