package com.com.app3;

/**
 * Created by Администратор on 17.07.2016.
 */
public class Thread2 extends Thread {
    private Person person;

    public Thread2(Person person) {
        this.person = person;
    }

    public void run() {
        synchronized (person) {
            System.out.println("Thread2." + person);
            person.setAge(2);
            person.setName("Name2");
            System.out.println("Thread2.After set values." + person);
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Thread2.Completed." + person);
        }
    }
}
