package com.app4;

/**
 * Created by Администратор on 17.07.2016.
 */
public class Thread4 extends Thread {
    private String a;
    private String b;

    public Thread4(String a, String b) {
        this.a = a;
        this.b = b;
    }

    public void run(){
        synchronized (b){
            System.out.println("Thread4.Got b");
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Thread4.After sleep");
            synchronized (a){
                System.out.println("Thread4.Got ");
            }
        }
    }
}
