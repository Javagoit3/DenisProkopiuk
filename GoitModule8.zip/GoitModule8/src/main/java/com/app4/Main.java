package com.app4;

/**
 * Created by Администратор on 17.07.2016.
 */
public class Main {

    public static void main(String[] args){
        String a = "A";
        String b = "B";
        Thread thread3 = new Thread3(a,b);
        Thread thread4 = new Thread4(a,b);
        thread3.start();
        thread4.start();
    }
}
