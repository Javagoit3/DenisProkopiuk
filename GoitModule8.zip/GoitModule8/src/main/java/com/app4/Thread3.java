package com.app4;

/**
 * Created by Администратор on 17.07.2016.
 */
public class Thread3 extends Thread {
    private String a;
    private String b;

    public Thread3(String a, String b) {
        this.a = a;
        this.b = b;
    }

    public void run(){
        synchronized (a){
            System.out.println("Thread3.Got a");
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Thread3.After sleep");
            synchronized (b){
                System.out.println("Thread3.Got ");
            }
        }
    }
}
