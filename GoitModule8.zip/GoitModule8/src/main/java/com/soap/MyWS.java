package com.soap;

import javax.xml.ws.Endpoint;

/**
 * Created by Администратор on 17.07.2016.
 */
public class MyWS {

    public static void main(String[] args){
        Endpoint.publish("http://127.0.0.1:8081/myWs", new RemoteCalculatorImpl());
    }

}
