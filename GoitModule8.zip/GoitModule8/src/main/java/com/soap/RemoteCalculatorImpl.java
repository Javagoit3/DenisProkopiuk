package com.soap;

import javax.jws.WebMethod;
import javax.jws.WebService;

/**
 * Created by Администратор on 17.07.2016.
 */
@WebService
public class RemoteCalculatorImpl implements RemoteCalculator {

    @WebMethod
    public int add(int a, int b) {
        System.out.println("a="+a);
        System.out.println("b="+b);
        int res=a+b;
        System.out.println("res="+res);
        return res;
    }
}
