package com.soap;

/**
 * Created by Администратор on 17.07.2016.
 */

public interface RemoteCalculator {

    public int add(int a, int b);
}
