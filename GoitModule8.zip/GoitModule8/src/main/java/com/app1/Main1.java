package com.app1;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Администратор on 17.07.2016.
 */
public class Main1 {

    public static void main(String[] args) throws InterruptedException {
        System.out.println("-----START-----");
        List<DenysTask> taskList = new ArrayList();
        for(int i=0;i<100;i++){
            DenysTask task = new DenysTask(i);
            taskList.add(task);
            task.start();
            //task.join();
        }
        for(DenysTask task:taskList){
            task.join();
        }

        System.out.println("-----FINISH-----");
    }

}
