package com.app1;

/**
 * Created by Администратор on 17.07.2016.
 */
public class DenysTask extends Thread{
    private int number;

    public DenysTask(int number) {
        this.number = number;
    }

    @Override
    public void run() {
        System.out.println("Thread #"+number+".Start");
        try {
            Thread.sleep(15000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Thread #"+number+".Finish");
    }
}
