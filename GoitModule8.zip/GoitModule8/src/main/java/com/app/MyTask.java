package com.app;

/**
 * Created by Администратор on 17.07.2016.
 */
public class MyTask implements Runnable {

    public void run() {
        System.out.println("MyRunnable");
    }
}
