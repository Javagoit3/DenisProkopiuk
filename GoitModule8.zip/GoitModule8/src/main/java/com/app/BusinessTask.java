package com.app;

/**
 * Created by Администратор on 17.07.2016.
 */
public class BusinessTask extends Thread {
    private String type;

    public BusinessTask(String type)
    {
        this.type = type;
    }

    public void run(){
        while(true){
            System.out.println(type);
            try {
                Thread.sleep(0);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }



        //dailyTask(type);
    }



    private void dailyTask(String type){
        System.out.println("BusinessTask. Type="+type);
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("BusinessTask.Completed. Type="+type);
    }

}
