package com.app;

/**
 * Created by Администратор on 17.07.2016.
 */
public class App1 {

    public static void main(String[] args){
        BusinessTask businessTaskA = new BusinessTask("A");
        businessTaskA.setPriority(Thread.MAX_PRIORITY);
        businessTaskA.setDaemon(false);

        BusinessTask businessTaskB = new BusinessTask("B");
        businessTaskB.setPriority(Thread.MIN_PRIORITY);
        businessTaskB.setDaemon(true);

        //businessTaskA.start();
        //businessTaskB.start();

        Runnable myTask = new MyTask();
        Thread myThread = new Thread(myTask);
        myThread.start();
    }
}
