package com.app5;

import java.util.Collection;
import java.util.List;

/**
 * Created by Администратор on 17.07.2016.
 */
public class DataThread extends Thread{
    private Collection<String> data;

    public DataThread(Collection<String> data) {
        this.data = data;
    }

    public void run(){
        for(String s: data){
            System.out.println(s);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
