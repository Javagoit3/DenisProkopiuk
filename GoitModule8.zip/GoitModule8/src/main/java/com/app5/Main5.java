package com.app5;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by Администратор on 17.07.2016.
 */
public class Main5 {

    public static void main(String[] args){
        DataModule dataModule = DataModule.getInstance();
        Collection<String> data = dataModule.getData();
        for(int i=0;i<100;i++){
            data.add("data"+i);
        }
        Thread t = new DataThread(data);
        Thread t2 = new DataThread2(data);
        t.start();
        t2.start();
    }
}
