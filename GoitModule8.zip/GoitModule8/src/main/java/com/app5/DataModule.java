package com.app5;

import java.util.*;
import java.util.concurrent.*;

/**
 * Created by Администратор on 17.07.2016.
 */
public class DataModule {
    private static DataModule instance;
    private Collection<String> data;// = new Vector();

    private DataModule(){
        data=Collections.synchronizedList(new ArrayList());
        //data=new ArrayList();
    }

    public Collection<String> getData() {
        return data;
    }

    public static DataModule getInstance(){
        if(instance==null){
            instance=new DataModule();
        }
        return instance;
    }
}
