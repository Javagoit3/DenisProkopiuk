package com.app5;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * Created by Администратор on 17.07.2016.
 */
public class DataThread2 extends Thread {

    private Collection<String> data;

    public DataThread2(Collection<String> data) {
        this.data = data;
    }

    public void run(){
        Iterator<String> itr=data.iterator();
        while(itr.hasNext()){
            String item=itr.next();
            System.out.println("\tRemove: "+item);
          //  itr.remove();
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
