package com.app2;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Администратор on 17.07.2016.
 */
public class Main2 {

    public static void main(String[] args){
        Timer timer = new Timer();
        TimerTask timerTask = new GoitTimerTask();
        timer.scheduleAtFixedRate(timerTask,0,1000);
        TimerTask personTask = new PersonTimerTask();
        timer.scheduleAtFixedRate(personTask,0,500);

    }
}
