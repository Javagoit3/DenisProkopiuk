package com.app2;

import java.util.TimerTask;

/**
 * Created by Администратор on 17.07.2016.
 */
public class PersonTimerTask extends TimerTask {


    @Override
    public void run() {
        System.out.println("\tPerson");
    }
}
