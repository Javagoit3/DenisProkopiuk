package example.set;

/**
 * Created by Администратор on 09.07.2016.
 */
public class Fish extends Pet {

    public Fish(String name, int age) {
        super(name, age);
    }
}
