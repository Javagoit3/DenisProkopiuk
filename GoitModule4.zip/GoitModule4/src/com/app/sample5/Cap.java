package com.app.sample5;

/**
 * Created by Администратор on 25.06.2016.
 */
public class Cap {
    private String color;

    public Cap(String color) {
        this.color = color;
    }

    public String getColor() {
        return color;
    }
}
