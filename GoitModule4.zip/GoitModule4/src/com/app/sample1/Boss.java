package com.app.sample1;

/**
 * Created by Администратор on 25.06.2016.
 */
public class Boss extends Employee {

   /* @Override
    public void validate() {

    }*/
}
