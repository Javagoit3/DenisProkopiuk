package com.app.sample2;

import com.app.sample2.pack1.Person;
import com.app.sample2.pack3.Dog;
import com.app.sample2.pack5.Car;

/**
 * Created by Администратор on 25.06.2016.
 */
public class App2 {

    public static void main(String[] args){
        /*
        private
            default
                protected
                    public
         */
        //default
  //  Student st = new
        //public
        Person p = new Person();

        //protected=default+children
        Dog dog = new Dog();
        //dog.myMethod();

        Car car = new Car();
        //car.
    }
}
