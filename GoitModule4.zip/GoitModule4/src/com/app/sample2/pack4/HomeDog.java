package com.app.sample2.pack4;

import com.app.sample2.pack3.Dog;

/**
 * Created by Администратор on 25.06.2016.
 */
public class HomeDog extends Dog {

    public void m2(){
        myMethod();
    }

}
