package com.app.sample2.pack3;

/**
 * Created by Администратор on 25.06.2016.
 */
public class DogHelper {

    public void m1(){
        Dog dog = new Dog();
        dog.myMethod();
    }
}
