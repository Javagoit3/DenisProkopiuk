package com.app.sample2.pack1;

/**
 * Created by Администратор on 25.06.2016.
 */
public class Person {

    public void method(){
       // Student student = new Student();
    }

}
