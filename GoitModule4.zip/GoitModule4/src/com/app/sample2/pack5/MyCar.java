package com.app.sample2.pack5;

/**
 * Created by Администратор on 25.06.2016.
 */
public class MyCar {

    public void m(){
        Car car = new Car();
        //car.
    }
}
