package com.app.sample2.pack2;

import com.app.sample2.pack1.Person;

/**
 * Created by Администратор on 25.06.2016.
 */
class Student {

    public void m(){
        Person p = new Person();
    }
}
