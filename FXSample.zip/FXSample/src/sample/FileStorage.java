package sample;

import java.io.*;
import java.util.List;

/**
 * Created by Администратор on 30.07.2016.
 */
public class FileStorage {
    private static final String PATH = "C://data.txt";

    public void save(List<Employee> data){
        try(ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(new File(PATH)))){
            out.writeObject(data);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Employee> load() {
        try(ObjectInputStream in = new ObjectInputStream(new FileInputStream(new File(PATH)))){
            return (List<Employee>) in.readObject();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
