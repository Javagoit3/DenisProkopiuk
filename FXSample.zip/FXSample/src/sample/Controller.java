package sample;

import javafx.beans.property.ReadOnlyIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableArrayBase;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionModel;
import javafx.scene.control.TextField;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class Controller implements Initializable{
    @FXML
    private TextField nameValue;
    @FXML
    private TextField departmentValue;
    @FXML
    private TextField ageValue;
    @FXML
    private ListView listView;
    @FXML
    private Button saveToFileButton;
    @FXML
    private Button loadFromFileButton;
    @FXML
    private Button cleanupButton;

    private FileStorage fileStorage;


    public void initialize(URL location, ResourceBundle resources) {
        fileStorage = new FileStorage();
        SelectionModel selectionModel = listView.getSelectionModel();
        ReadOnlyIntegerProperty readOnlyIntegerProperty = selectionModel.selectedIndexProperty();
        readOnlyIntegerProperty.addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                Employee currentItem= (Employee) listView.getItems().get(newValue.intValue());
                updateForm(currentItem);
            }
        });

    }


    @FXML
    private void handleSaveAction(ActionEvent event) {
        String name=nameValue.getText();
        String department = departmentValue.getText();
        int age = Integer.parseInt(ageValue.getText());
        Employee emp = new Employee();
        emp.setAge(age);
        emp.setName(name);
        emp.setDepartment(department);
        listView.getItems().add(emp);
        cleanUpForm();
    }

    @FXML
    private void handleUpdateAction(ActionEvent event) {
        int index=listView.getSelectionModel().getSelectedIndex();
        Employee currentItem= (Employee) listView.getItems().get(index);
        String name=nameValue.getText();
        String department = departmentValue.getText();
        int age = Integer.parseInt(ageValue.getText());
        Employee emp = new Employee();
        emp.setAge(age);
        emp.setName(name);
        emp.setDepartment(department);
        listView.getItems().set(index,emp);
    }

    @FXML
    private void handleRemoveAction(ActionEvent event) {
        int index=listView.getSelectionModel().getSelectedIndex();
        listView.getItems().remove(index);
    }

    @FXML
    private void handleSaveToFileAction(ActionEvent event) {
        ObservableList<Employee> list=listView.getItems();
        List<Employee> data = new ArrayList();
        for(Employee emp:list){
            data.add(emp);
        }
        fileStorage.save(data);
    }

    @FXML
    private void handleLoadFromFile(ActionEvent event) {
        List<Employee> list=fileStorage.load();
        listView.getItems().addAll(list);
    }

    @FXML
    private void handlecleanupAction(ActionEvent event) {
        listView.getItems().clear();
    }

    private void cleanUpForm(){
        nameValue.setText("");
        departmentValue.setText("");
        ageValue.setText("");
    }

    private void updateForm(Employee emp){
        nameValue.setText(emp.getName());
        departmentValue.setText(emp.getDepartment());
        ageValue.setText(emp.getAge()+"");
    }
}
