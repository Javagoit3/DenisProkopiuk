package com;

public class HelloAntApp{

	public static void main(String[] args){
		System.out.println("Test.This is ANT!!!");
		
	}
	
}