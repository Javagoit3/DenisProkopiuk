package com.dao;

import com.app.*;

import java.util.List;

/**
 * Created by Администратор on 21.07.2016.
 */
public class App2 {

    public static void main(String[] args) throws Exception {
        DAO dao = new DAOImpl();
        int count=dao.getCountOfRecords();
        System.out.println("Count="+count);
        int sum=dao.getSumOfAge();
        System.out.println("Sum Of Age="+sum);
        sum=dao.getSumOfAge("Name1");
        System.out.println("Sum Of Age(name1)="+sum);
        double avg=dao.getAvgAge();
        System.out.println("AVG Of Age="+avg);
       /* Consumer consumer = new ConsumerImpl();
        List<Person> persons=consumer.readFromXls("result.xls");
        dao.saveToDb(persons);

        persons=dao.getAllPersonsFromDb();
        Producer producer = new ProducerImpl();
        producer.writeToXls(persons,"result.xls");
*/
    }

}
