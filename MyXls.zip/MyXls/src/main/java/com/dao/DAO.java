package com.dao;

import com.app.Person;

import java.util.List;

/**
 * Created by Администратор on 21.07.2016.
 */
public interface DAO {

    public int getCountOfRecords();

    public double getAvgAge();

    public int getSumOfAge();

    public int getSumOfAge(String name);

    public void saveToDb(List<Person> persons);

    public List<Person> getAllPersonsFromDb();
}
