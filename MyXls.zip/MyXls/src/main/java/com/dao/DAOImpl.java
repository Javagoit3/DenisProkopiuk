package com.dao;

import com.app.Person;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


/**
 * Created by Администратор on 21.07.2016.
 */
public class DAOImpl implements DAO{

    /*static {
        try {
            //com.mysql.jdbc.Driver
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }*/


    @Override
    public int getCountOfRecords() {
        Connection c = null;
        try{
            c = getConnection();
            Statement st=c.createStatement();
            ResultSet rs=st.executeQuery("SELECT COUNT(*) from PERSONS");
            int count=0;
            while(rs.next()){
                count=rs.getInt(1);
            }
            return count;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally{
            if(c!=null){
                try {
                    c.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        }


    }

    @Override
    public double getAvgAge() {
        try(Connection c = getConnection()){
            Statement st=c.createStatement();
            ResultSet rs=st.executeQuery("SELECT AVG(age) from PERSONS");
            double avg=0;
            while(rs.next()){
                avg=rs.getDouble(1);
            }
            return avg;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int getSumOfAge(String name) {
        try(Connection c = getConnection()){
            //Statement st=c.createStatement();
           // ResultSet rs=st.executeQuery("SELECT SUM(age) from PERSONS where name='"+name+"'");
            PreparedStatement ps=c.prepareStatement("SELECT SUM(age) from PERSONS where name=?");
            ps.setString(1, name);
            ResultSet rs=ps.executeQuery();
            int sum=0;
            while(rs.next()){
                sum=rs.getInt(1);
            }
            return sum;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int getSumOfAge() {
        try(Connection c = getConnection()){
            Statement st=c.createStatement();
            ResultSet rs=st.executeQuery("SELECT SUM(age) from PERSONS");
            int sum=0;
            while(rs.next()){
                sum=rs.getInt(1);
            }
            return sum;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void saveToDb(List<Person> persons) {
        try(Connection c = getConnection()){
            for(Person p:persons) {
                PreparedStatement ps = c.prepareStatement("INSERT INTO persons (name, age) values(?,?)");
                ps.setString(1, p.getName());
                ps.setInt(2, p.getAge());
                ps.execute();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Person> getAllPersonsFromDb() {
        List<Person> persons = new ArrayList();
        try(Connection c = getConnection()){
            Statement st=c.createStatement();
            ResultSet rs=st.executeQuery("SELECT * from persons");
            while(rs.next()){
                int age = rs.getInt("age");
                String name = rs.getString("name");
                Person p = new Person();
                p.setAge(age);
                p.setName(name);
                persons.add(p);
            }
            return persons;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my","root","11111111");
    }
}
