package com.app;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.List;

/**
 * Created by Администратор on 21.07.2016.
 */
public class ProducerImpl implements Producer{

    public void writeToXls(List<Person> persons, String path)throws Exception {
        System.out.println("writeToXls Started");
        Workbook workbook = new HSSFWorkbook();
        Sheet sheet = workbook.createSheet("Persons");
        for(int i=0;i<persons.size();i++){
            System.out.println(""+i);
            Row row=sheet.createRow(i);
            int j=0;
            Person p = persons.get(i);
            Cell cell=row.createCell(j++);
            cell.setCellValue(p.getName());
            cell=row.createCell(j++);
            cell.setCellValue(p.getAge());
        }
        try(OutputStream out = new FileOutputStream(new File(path))) {
            workbook.write(out);
            //out.flush();
        }
        System.out.println("writeToXls Completed");
    }
}
