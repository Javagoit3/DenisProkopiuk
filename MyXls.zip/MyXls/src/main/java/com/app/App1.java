package com.app;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Администратор on 21.07.2016.
 */
public class App1 {

    public static void main(String[] args) throws Exception {
        List<Person> persons = initTestData(10);
        Producer producer = new ProducerImpl();
        String path="result.xls";
        //producer.writeToXls(persons, path);
        Consumer consumer = new ConsumerImpl();
        persons=consumer.readFromXls(path);
        for(Person p:persons){
            System.out.println(p);
        }
    }


    private static List<Person> initTestData(int n){
        List<Person> list = new ArrayList<>();
        for(int i=0;i<n;i++){
            Person p = new Person();
            p.setAge(i);
            p.setName("Name"+i);
            list.add(p);
        }
        return list;
    }
}
