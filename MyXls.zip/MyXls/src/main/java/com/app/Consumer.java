package com.app;

import java.util.List;

/**
 * Created by Администратор on 21.07.2016.
 */
public interface Consumer {

    public List<Person> readFromXls(String path) throws Exception;
}
