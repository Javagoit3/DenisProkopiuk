package com.app;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Администратор on 21.07.2016.
 */
public class ConsumerImpl implements Consumer {

    @Override
    public List<Person> readFromXls(String path) throws Exception {
        List<Person> persons  = new ArrayList<>();
        Workbook workbook = readWorkbook(path);
        Sheet sheet = workbook.getSheetAt(0);
        for(Row row: sheet){
            String name=row.getCell(0).getStringCellValue();
            int age = (int)row.getCell(1).getNumericCellValue();
           // int age = Integer.parseInt(row.getCell(1).getStringCellValue());
            Person p = new Person();
            p.setName(name);
            p.setAge(age);
            persons.add(p);
        }
        return persons;
    }

    private Workbook readWorkbook(String path) throws Exception {
        InputStream in = new FileInputStream(new File(path));
        return new HSSFWorkbook(in);
    }
}
