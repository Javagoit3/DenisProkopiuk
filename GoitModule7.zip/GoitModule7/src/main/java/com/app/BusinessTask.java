package com.app;

import java.util.List;

/**
 * Created by Администратор on 14.07.2016.
 */
public interface BusinessTask {

    public void save(Person person);

    public void bulkSave(List<Person> person);

    public List<Person> getAllPersons();

    public Person getPerson(String name);

    public Person getPerson(int age);

    public int getSize();
}
