package com.app;

/**
 * Created by Администратор on 14.07.2016.
 */
public enum EnumSingleton {
    INSTANCE;

    public void m1(String message){
        System.out.println(message);
    }


    public void m2(){

    }

}
