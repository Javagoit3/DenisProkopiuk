package com.goit.module5._interface;

/**
 * Created by Администратор on 30.06.2016.
 */
public interface Color {

    public void colorInfo();
}
