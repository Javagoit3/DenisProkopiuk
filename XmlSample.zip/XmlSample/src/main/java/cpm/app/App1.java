package cpm.app;

import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.InputStream;

/**
 * Created by Администратор on 22.07.2016.
 */
public class App1 {

    public static void main(String[] args) throws Exception {
        SAXParserFactory factory=SAXParserFactory.newInstance();
        SAXParser parser=factory.newSAXParser();
        App1 app = new App1();
        InputStream in = app.getResourceAsStream("/persons.xml");
        parser.parse(in, new MySaxHandler());
    }


    private InputStream getResourceAsStream(String path){
        return getClass().getResourceAsStream(path);
    }

}
