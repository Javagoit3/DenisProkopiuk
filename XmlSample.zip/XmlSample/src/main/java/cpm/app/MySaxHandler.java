package cpm.app;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Администратор on 22.07.2016.
 */
public class MySaxHandler extends DefaultHandler {

    /*
    WHERE,
    GROUP BY
    HAVING,
    AVG, SUM, COUNT, MIN, MAX
    LIMIT
    JOIN
    http://www.sql.ru/docs/sql/u_sql/ch20.shtml


     */


    private List<Person> persons = new ArrayList();
    private String currentTag;

    @Override
    public void startDocument() throws SAXException {
        System.out.println("Parsing started");
    }


    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
       // System.out.println("\tStarted tag="+qName);
        currentTag=qName;
        if("person".equals(qName)){
            persons.add(new Person());
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        String value = new String(ch, start, length);
        if(value.trim().isEmpty()){
            return;
        }
       // System.out.println("\t\t"+value);
        if("age".equals(currentTag)){
            int age = Integer.parseInt(value);
            persons.get(persons.size()-1).setAge(age);
        }
        if("name".equals(currentTag)){
            persons.get(persons.size()-1).setName(value);
        }

    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        System.out.println("\tEnd tag="+qName);
    }

    @Override
    public void endDocument() throws SAXException {
        System.out.println("Parsing completed");
        for(Person p:persons){
            System.out.println(p);
        }
    }

}
